const config = {
    type: Phaser.AUTO,
    width: window.innerWidth, // Use full screen width
    height: window.innerHeight, // Use full screen height
    backgroundColor: '#00FFFF', // Start with cyan background
    parent: 'game-container', // Attach the game to the div in the HTML
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

const game = new Phaser.Game(config);

let level = 1;
let stage = 1;
let lives = 3;
let questionText;
let answerButtons = [];
let selectedLanguage = 'english'; // Default language
let selectedTheme = '#00FFFF'; // Default theme
const colors = ['#FF0000', '#FF7F00', '#FFFF00', '#00FF00', '#0000FF', '#4B0082', '#9400D3']; // Colorful colors

// Language-specific text
const languageText = {
    english: {
        madeBy: 'Made by William',
        stage: 'Stage',
        level: 'Level',
        lives: 'Lives',
        gameOver: 'Game Over',
        restart: 'Restart',
        clearCache: 'Clear Cache',
        clearCacheWarning: 'Warning: This will delete your game progress!',
        confirm: 'Confirm',
        cancel: 'Cancel',
        youWin: 'You Win! 100,000 Aura',
        startGame: 'Start Game',
        settings: 'Settings',
        theme: 'Theme',
        chooseStage: 'Choose Stage',
        language: 'Language'
    },
    chinese: {
        madeBy: '由威廉制作',
        stage: '阶段',
        level: '等级',
        lives: '生命',
        gameOver: '游戏结束',
        restart: '重新开始',
        clearCache: '清除缓存',
        clearCacheWarning: '警告：这将删除您的游戏进度！',
        confirm: '确认',
        cancel: '取消',
        youWin: '你赢了！100,000 灵气',
        startGame: '开始游戏',
        settings: '设置',
        theme: '主题',
        chooseStage: '选择阶段',
        language: '语言'
    },
    japanese: {
        madeBy: 'ウィリアム作成',
        stage: 'ステージ',
        level: 'レベル',
        lives: 'ライフ',
        gameOver: 'ゲームオーバー',
        restart: '再開',
        clearCache: 'キャッシュをクリア',
        clearCacheWarning: '警告：これによりゲームの進捗が削除されます！',
        confirm: '確認',
        cancel: 'キャンセル',
        youWin: 'あなたの勝ち！100,000 オーラ',
        startGame: 'ゲームを始める',
        settings: '設定',
        theme: 'テーマ',
        chooseStage: 'ステージを選択',
        language: '言語'
    },
    korean: {
        madeBy: '윌리엄 제작',
        stage: '스테이지',
        level: '레벨',
        lives: '생명',
        gameOver: '게임 오버',
        restart: '재시작',
        clearCache: '캐시 지우기',
        clearCacheWarning: '경고: 이 작업은 게임 진행 상황을 삭제합니다!',
        confirm: '확인',
        cancel: '취소',
        youWin: '당신이 이겼습니다! 100,000 오라',
        startGame: '게임 시작',
        settings: '설정',
        theme: '테마',
        chooseStage: '스테이지 선택',
        language: '언어'
    }
};

// 100 unique questions with clear context
const questions = [
    { question: "Which punctuation is missing: 'Hello __ world'", options: [",", ".", "!", "?"], answer: "," },
    { question: "Which punctuation is missing: 'How are you __'", options: [".", "!", "?", ","], answer: "?" },
    { question: "Which punctuation is missing: 'I love coding __'", options: [".", "!", "?", ","], answer: "!" },
    { question: "Which punctuation is missing: 'The sky is blue __'", options: [".", "!", "?", ","], answer: "." },
    { question: "Which punctuation is missing: 'Wow __ that's amazing'", options: [",", ".", "!", "?"], answer: "!" },
    { question: "Which punctuation is missing: 'What is your name __'", options: [".", "!", "?", ","], answer: "?" },
    { question: "Which punctuation is missing: 'Let's go to the park __'", options: [".", "!", "?", ","], answer: "." },
    { question: "Which punctuation is missing: 'This is so exciting __'", options: [".", "!", "?", ","], answer: "!" },
    { question: "Which punctuation is missing: 'She said __ Hello __'", options: ["'", '"', ".", ","], answer: '"' },
    { question: "Which punctuation is missing: 'The cat __ sat on the mat'", options: [",", ".", "!", "?"], answer: "," },
    // Add 90 more questions here...
];

// Punctuation marks grouped by difficulty
const punctuationMarks = {
    easy: ['.', ',', '!', '?'],
    medium: [';', ':', '"', "'"],
    hard: ['(', ')', '—', '…']
};

function preload() {
    this.load.image('button', 'button.png');
}

function create() {
    // Show game menu at the start
    showGameMenu.call(this);
}

function clearUI() {
    // Destroy all children of the scene
    this.children.each(child => child.destroy());
}

function showGameMenu() {
    clearUI.call(this); // Clear existing UI elements
    this.cameras.main.setBackgroundColor(selectedTheme); // Set background color

    // "Made by William" text at the top left
    this.add.text(20, 20, languageText[selectedLanguage].madeBy, {
        fontSize: '20px',
        fill: '#FFF',
        fontStyle: 'bold',
        backgroundColor: '#333',
        padding: { x: 10, y: 5 }
    });

    // Start Game button in the middle
    let startGameButton = this.add.text(this.cameras.main.centerX, this.cameras.main.centerY - 50, languageText[selectedLanguage].startGame, {
        fontSize: '32px',
        fill: '#FFF',
        backgroundColor: '#333',
        padding: { x: 20, y: 10 }
    })
        .setInteractive()
        .on('pointerdown', () => {
            clearUI.call(this); // Clear UI before starting the game
            startGame.call(this);
        })
        .setOrigin(0.5); // Center the text

    // Settings button below Start Game
    let settingsButton = this.add.text(this.cameras.main.centerX, this.cameras.main.centerY + 50, languageText[selectedLanguage].settings, {
        fontSize: '32px',
        fill: '#FFF',
        backgroundColor: '#333',
        padding: { x: 20, y: 10 }
    })
        .setInteractive()
        .on('pointerdown', () => {
            clearUI.call(this); // Clear UI before showing settings
            showSettingsMenu.call(this);
        })
        .setOrigin(0.5); // Center the text
}

function showSettingsMenu() {
    clearUI.call(this); // Clear existing UI elements

    // Theme selection button
    let themeButton = this.add.text(this.cameras.main.centerX, this.cameras.main.centerY - 150, languageText[selectedLanguage].theme, {
        fontSize: '32px',
        fill: '#FFF',
        backgroundColor: '#333',
        padding: { x: 20, y: 10 }
    })
        .setInteractive()
        .on('pointerdown', () => {
            clearUI.call(this); // Clear UI before showing theme selection
            showThemeSelection.call(this);
        })
        .setOrigin(0.5); // Center the text

    // Choose Stage button
    let chooseStageButton = this.add.text(this.cameras.main.centerX, this.cameras.main.centerY - 50, languageText[selectedLanguage].chooseStage, {
        fontSize: '32px',
        fill: '#FFF',
        backgroundColor: '#333',
        padding: { x: 20, y: 10 }
    })
        .setInteractive()
        .on('pointerdown', () => {
            clearUI.call(this); // Clear UI before showing stage selection
            showStageSelection.call(this);
        })
        .setOrigin(0.5); // Center the text

    // Language selection button
    let languageButton = this.add.text(this.cameras.main.centerX, this.cameras.main.centerY + 50, languageText[selectedLanguage].language, {
        fontSize: '32px',
        fill: '#FFF',
        backgroundColor: '#333',
        padding: { x: 20, y: 10 }
    })
        .setInteractive()
        .on('pointerdown', () => {
            clearUI.call(this); // Clear UI before showing language selection
            showLanguageSelection.call(this);
        })
        .setOrigin(0.5); // Center the text

    // Back to Game Menu button
    let backButton = this.add.text(this.cameras.main.centerX, this.cameras.main.centerY + 150, 'Back', {
        fontSize: '32px',
        fill: '#FFF',
        backgroundColor: '#333',
        padding: { x: 20, y: 10 }
    })
        .setInteractive()
        .on('pointerdown', () => {
            clearUI.call(this); // Clear UI before going back to the game menu
            showGameMenu.call(this);
        })
        .setOrigin(0.5); // Center the text
}

function showThemeSelection() {
    clearUI.call(this); // Clear existing UI elements

    // Display 7 colorful themes
    colors.forEach((color, index) => {
        let themeButton = this.add.text(this.cameras.main.centerX, 100 + index * 50, `Theme ${index + 1}`, {
            fontSize: '24px',
            fill: '#FFF',
            backgroundColor: color,
            padding: { x: 10, y: 5 }
        })
            .setInteractive()
            .on('pointerdown', () => {
                selectedTheme = color;
                this.cameras.main.setBackgroundColor(color);
                clearUI.call(this); // Clear UI before going back to the game menu
                showGameMenu.call(this);
            })
            .setOrigin(0.5); // Center the text
    });

    // Back to Settings button
    let backButton = this.add.text(this.cameras.main.centerX, 500, 'Back', {
        fontSize: '32px',
        fill: '#FFF',
        backgroundColor: '#333',
        padding: { x: 20, y: 10 }
    })
        .setInteractive()
        .on('pointerdown', () => {
            clearUI.call(this); // Clear UI before going back to settings
            showSettingsMenu.call(this);
        })
        .setOrigin(0.5); // Center the text
}

function showStageSelection() {
    clearUI.call(this); // Clear existing UI elements

    // Display stages 1-10
    for (let i = 1; i <= 10; i++) {
        let stageButton = this.add.text(this.cameras.main.centerX, 100 + (i - 1) * 50, `Stage ${i}`, {
            fontSize: '24px',
            fill: '#FFF',
            backgroundColor: '#333',
            padding: { x: 10, y: 5 }
        })
            .setInteractive()
            .on('pointerdown', () => {
                stage = i;
                level = 1;
                clearUI.call(this); // Clear UI before starting the game
                startGame.call(this);
            })
            .setOrigin(0.5); // Center the text
    }

    // Back to Settings button
    let backButton = this.add.text(this.cameras.main.centerX, 600, 'Back', {
        fontSize: '32px',
        fill: '#FFF',
        backgroundColor: '#333',
        padding: { x: 20, y: 10 }
    })
        .setInteractive()
        .on('pointerdown', () => {
            clearUI.call(this); // Clear UI before going back to settings
            showSettingsMenu.call(this);
        })
        .setOrigin(0.5); // Center the text
}

function showLanguageSelection() {
    clearUI.call(this); // Clear existing UI elements

    // Display 4 languages
    const languages = ['english', 'chinese', 'japanese', 'korean'];
    languages.forEach((lang, index) => {
        let languageButton = this.add.text(this.cameras.main.centerX, 100 + index * 50, lang.toUpperCase(), {
            fontSize: '24px',
            fill: '#FFF',
            backgroundColor: '#333',
            padding: { x: 10, y: 5 }
        })
            .setInteractive()
            .on('pointerdown', () => {
                selectedLanguage = lang;
                clearUI.call(this); // Clear UI before going back to the game menu
                showGameMenu.call(this); // Go back to the game menu
            })
            .setOrigin(0.5); // Center the text
    });

    // Back to Settings button
    let backButton = this.add.text(this.cameras.main.centerX, 400, 'Back', {
        fontSize: '32px',
        fill: '#FFF',
        backgroundColor: '#333',
        padding: { x: 20, y: 10 }
    })
        .setInteractive()
        .on('pointerdown', () => {
            clearUI.call(this); // Clear UI before going back to settings
            showSettingsMenu.call(this);
        })
        .setOrigin(0.5); // Center the text
}

function startGame() {
    clearUI.call(this); // Clear existing UI elements
    this.cameras.main.setBackgroundColor(selectedTheme); // Set selected theme

    // Display game info
    this.add.text(20, 20, languageText[selectedLanguage].madeBy, { fontSize: '20px', fill: '#FFF' });
    this.stageText = this.add.text(20, 50, `${languageText[selectedLanguage].stage}: ${stage}`, { fontSize: '20px', fill: '#FFF' });
    this.levelText = this.add.text(20, 80, `${languageText[selectedLanguage].level}: ${level}`, { fontSize: '20px', fill: '#FFF' });
    this.livesText = this.add.text(20, 110, `${languageText[selectedLanguage].lives}: ${lives}`, { fontSize: '20px', fill: '#FFF' });

    // Display question
    questionText = this.add.text(this.cameras.main.centerX, 200, '', {
        fontSize: '24px',
        fill: '#FFF',
        wordWrap: { width: this.cameras.main.width - 40 } // Ensure text wraps within the screen
    }).setOrigin(0.5); // Center the text

    generateQuestion.call(this);
}

function generateQuestion() {
    if (stage === 10 && level === 10) {
        // Player has won
        this.add.text(this.cameras.main.centerX, 300, languageText[selectedLanguage].youWin, { fontSize: '40px', fill: '#FFF' }).setOrigin(0.5);
        return;
    }

    let questionData = questions[level - 1]; // Get the current question
    let correctAnswer = questionData.answer;
    let answers = [correctAnswer];
    
    // Add random incorrect answers based on difficulty
    while (answers.length < 4) {
        let randomMark = Phaser.Math.RND.pick(punctuationMarks[getDifficulty()]);
        if (!answers.includes(randomMark)) {
            answers.push(randomMark);
        }
    }
    Phaser.Utils.Array.Shuffle(answers);

    questionText.setText(questionData.question);

    answerButtons.forEach(button => button.destroy());
    answerButtons = [];
    
    for (let i = 0; i < answers.length; i++) {
        let btn = this.add.text(this.cameras.main.centerX, 250 + i * 50, answers[i], {
            fontSize: '24px',
            fill: '#FFF',
            backgroundColor: '#333',
            padding: { x: 10, y: 5 }
        })
            .setInteractive()
            .on('pointerdown', () => checkAnswer.call(this, answers[i], correctAnswer))
            .setOrigin(0.5); // Center the text
        answerButtons.push(btn);
    }
}

function getDifficulty() {
    if (stage <= 3) return 'easy';
    if (stage <= 6) return 'medium';
    return 'hard'; // Stage 7 and above
}

function checkAnswer(selected, correct) {
    if (selected === correct) {
        level++;
        if (level > 10) {
            level = 1;
            stage++;
        }
        this.levelText.setText(`${languageText[selectedLanguage].level}: ${level}`);
        this.stageText.setText(`${languageText[selectedLanguage].stage}: ${stage}`);
        generateQuestion.call(this);
    } else {
        lives--;
        if (lives < 0) lives = 0; // Prevent lives from going below 0
        this.livesText.setText(`${languageText[selectedLanguage].lives}: ${lives}`);
        if (lives === 0) {
            gameOver.call(this);
        } else {
            generateQuestion.call(this);
        }
    }
}

function gameOver() {
    this.add.text(this.cameras.main.centerX, 300, languageText[selectedLanguage].gameOver, { fontSize: '40px', fill: '#FFF' }).setOrigin(0.5);
    
    // Add restart button
    let restartButton = this.add.text(this.cameras.main.centerX, 400, languageText[selectedLanguage].restart, {
        fontSize: '24px',
        fill: '#FFF',
        backgroundColor: '#333',
        padding: { x: 10, y: 5 }
    })
        .setInteractive()
        .on('pointerdown', () => {
            // Reset game state (stage, level, lives)
            stage = 1;
            level = 1;
            lives = 3;
            clearUI.call(this); // Clear UI before restarting
            this.scene.restart(); // Restart the game
        })
        .setOrigin(0.5); // Center the text
}

function update() {}